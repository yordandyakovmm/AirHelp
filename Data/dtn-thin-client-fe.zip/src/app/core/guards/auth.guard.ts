import { Injectable, isDevMode } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate } from '@angular/router';
import { AuthUserService } from '@px-core/services/auth-user.service';
import { environment } from '@env/environment';
import { WebsocketService } from '@px-core/services/websocket.service';
import { LogInMessage } from '@px-core/models/messages.model';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private authUserService: AuthUserService, private webSocketService: WebsocketService) {

  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {

    if (this.authUserService.hasAuthUser()) {
      return true;
    }

    this.router.navigate(['/login']);
    return false;
  }

}
