import { Injectable } from '@angular/core';

@Injectable()
export class LoadingSettingsService {

  loadingSettings = {
    labelStyle: {
      backgroundImage: 'url("/assets/loader.gif")',
      backgroundSize: 'contain',
      backgroundRepeat: 'no-repeat',
      display: 'inline-block',
      width: '60px',
      height: '60px',
      position: 'relative',
    },
    style: {
      backgroundColor: 'transparent',
      opacity: '0.5',
      position: 'absolute',
      textAlign: 'center',
      height: '100%',
      left: 0,
      top: 0
    }
  };

  constructor() { }
}
