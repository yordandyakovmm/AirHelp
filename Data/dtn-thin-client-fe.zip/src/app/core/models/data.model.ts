export class QuoteListModel {
  group: string;
  symbols: Array<SymbolModel>;
  constructor(group: string, symbols: Array<SymbolModel>) {
    this.group = group;
    this.symbols = symbols;
  }
}

export class SymbolModel {
  expression: string;
  fields: Array<string>;
  requestId: string;
  constructor(expression: string, fields: Array<string>, requestId: string) {
    this.expression = expression;
    this.fields = fields;
    this.requestId = requestId;
  }
}
