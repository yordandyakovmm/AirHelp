import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {
  // remove the value of the property once you connect the websocket data
  newsFormMessage: any = [
    { img: 'http://i.imgur.com/hfH9CiC.png', creator: 'The PRICE Futures Group', title: 'Morning Grains Report', date: '37 minutes ago',
      body: 'creator: The PRICE Futures Group, title: Morning Grains Report, date: 37 minutes ago', type: 'Grains' },
    { img: 'http://i.imgur.com/hfH9CiC.png', creator: 'The Hueber Report', title: 'Morning Grain Market Research', date: '49 minutes ago',
      body: `creator: The PRICE Futures Group, title: Morning Grains Report, date:
      37 minutes ago, creator: The PRICE Futures Group, title: Morning Grains Report, date: 37 minutes ago`, type: 'Grains' },
    {
      // img: 'http://i.imgur.com/hfH9CiC.png',
      creator: 'RCG Direct',
      title: 'Daily Technical Spotlight - January Soybeans',
      date: 'Thu Nov 16, 9:16AM CST',
      body: 'creator: The PRICE Futures Group, title: Morning Grains Report, date: 37 minutes ago',
      type: 'Technology & Computers'
    }];
  futuresNewsList: any = ['All Sectors', 'Currencies', 'Energies', 'Financials', 'Grains', 'Indices', 'Meats', 'Metals', 'Softs'];
  sectorNewsList: any = [ 'Aerospace', 'Agriculture', 'Buisness Service', 'Construction', 'Consumer Products', 'Corporate',
                          'Economy', 'Energy & Oil', 'Finance & Banking', 'Industrial Products', 'Leisure & Recreation',
                          'Media', 'Medical', 'Retail Sales', 'Technology & Computers', 'Transportation', 'Utilities'];
  activeFilter: String = 'All Sectors';
  filteredNews: any = this.newsFormMessage;
  name: String = 'NEWS';

  constructor() { }

  ngOnInit() {
  }

  getActiveFilter(element) {
    return element === this.activeFilter;
  }

  changeActiveFilter(element) {
    if (element === 'All Sectors') {
      this.filteredNews = this.newsFormMessage;
    } else {
      this.filteredNews = this.newsFormMessage.filter(n => n.type === element);
    }
    this.activeFilter = element;
  }
}
