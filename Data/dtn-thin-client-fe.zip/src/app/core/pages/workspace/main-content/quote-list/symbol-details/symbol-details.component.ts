import { Component, OnInit, Input, AfterViewInit, Output, EventEmitter } from '@angular/core';
import * as Highcharts from 'highcharts/highstock';
import * as SimpleHighcharts from 'highcharts';
import * as Exporting from 'highcharts/modules/exporting';
import * as moment from 'moment';
import { ChartsService } from "@px-core/services/charts.service";
import { ChartWatchRequest } from "@px-core/models/messages.model";
import { ChartTick } from "@px-core/models/chart-tick.model";
import { StorageService } from "@px-core/services/storage.service";
import { DomStateService } from '@px-core/services/dom-state.service';
import { LoadingSettingsService } from '@px-core/services/loading-settings.service';

@Component({
  selector: 'app-symbol-details',
  templateUrl: './symbol-details.component.html',
  styleUrls: ['./symbol-details.component.scss']
})
export class SymbolDetailsComponent implements OnInit, AfterViewInit {

  @Input() symbol: any;
  requestId: string;
  chart: any;
  lastChartTick: ChartTick;
  isClosePriceIncreasing: boolean = true;
  closePriceDifference: number = 0.00;
  isFullChartClosed = false;

  styleOptions = [
    'Style'
  ];
  seasonalOptions = [
    'Seasonal'
  ];

  selectedStyleOptions = this.styleOptions[0];
  selectedSeasonalOptions = this.seasonalOptions[0];

  constructor(private chartService: ChartsService,
              private storageService: StorageService,
              private domStateService: DomStateService,
              private loadingSettingsService: LoadingSettingsService) {
  }

  ngOnInit() {
    this.domStateService.setQuoteSymbolExpanded(true);

    this.requestId = new Date().getTime().toString() + this.symbol;
    const request = new ChartWatchRequest(this.requestId, this.symbol, 1000, 'DAY', 1, 5 );

    this.chartService.loadChartWatch(request);
  }

  ngAfterViewInit() {
    Exporting(Highcharts);
    Exporting(SimpleHighcharts);

    this.initChart('bigchart');
    this.initChartWatchSubscriber();
  }

  /**
   * Initialize and configure the chart in this component.
   * @param {string} selector
   */
  initChart(selector: string) {
    this.chart = SimpleHighcharts.chart(selector, {
      chart: {
        backgroundColor: 'transparent',
        // events: {
        //   load: []
        // }
      },
      colors: ['#b1b1b1'],
      yAxis: {
        opposite: true,
        gridLineColor: '#3C3C3C',
        title: {
          text: '',
        },
        type: 'logarithmic'
      },
      xAxis: {
        tickColor: '#2C2C2C',
        lineColor: '#3C3C3C',
        type: 'datetime',
        dateTimeLabelFormats: { // don't display the dummy year
          month: '%e. %b',
          year: '%b'
        },
      },
      rangeSelector: {
        selected: 1
      },

      title: {
        text: '',
        enabled: false,
      },
      legend: {
        enabled: false,
      },

      plotOptions: {
        series: {
          marker: {
            enabled: false
          }
        }
      },

      series: [{
        data: [],
        lineWidth: 4,
        tooltip: {
          valueDecimals: 2
        }
      }],
      exporting: {
        enabled: false,
      },
      credits: {
        enabled: false,
      },
      loading: this.loadingSettingsService.loadingSettings
    });

    // init loading
    this.chart.showLoading(' ');
  }

  /**
   * Subscribe to the ChartWatch command on the selected symbol.
   */
  initChartWatchSubscriber() {
    this.chartService.getChartWatch().subscribe(message => {
      if (message !== undefined) {
        if (message.meta.requestId === this.requestId && message.data !== undefined) {


          const chartTicks: ChartTick[] = message.data;

          let data = [];
          chartTicks.forEach(tick => {
            const tickDate = Number(moment(tick.DateTime).format('X')) * 1000;
            const tickClose = Number(tick.Close.number);

            data.push([tickDate, tickClose]);
          });

          let lastDataItem = data[data.length - 1];

          if (this.lastChartTick && data.length > 0) {

            let lastChartTickClose: number = this.lastChartTick.Close.number;
            let lastDataClose: number = parseFloat(Number(lastDataItem[1]).toFixed(2));

            this.isClosePriceIncreasing = (lastChartTickClose < lastDataClose);
            this.closePriceDifference = (lastDataClose - lastChartTickClose);

          }

          this.lastChartTick = message.data[message.data.length - 1];

          this.addChartData(this.chart, data);

        }
      }
    });
  }

  /**
   * Add new ticks to the chart.
   * @param chart
   * @param data
   */
  addChartData(chart, data) {

    data.forEach(item => {

      let pushData: boolean = false;

      if (chart.series[0].data.length > 100) {
        pushData = true;
      }

      if (chart.series[0].data.length > 0) {
        let lastDate = chart.series[0].data[chart.series[0].data.length - 1].x;

        if (lastDate !== item[0]) {
          chart.series[0].addPoint(item, false, pushData);
        }
      } else {
        chart.series[0].addPoint(item, false, pushData);
      }

    });

    chart.redraw();
    chart.reflow();
    chart.hideLoading();
  }

  collapseDetails() {
    this.domStateService.setQuoteSymbolExpanded(false);
  }
}
