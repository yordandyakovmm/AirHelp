export class ChartTick {
  DateTime: string;
  Open: string;
  High: string;
  Low: string;
  Close: {text: string; number: number};
  Volume: number;
  OpenInt: number;
}
