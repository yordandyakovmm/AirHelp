import { Injectable } from '@angular/core';
import { WebsocketService } from '@px-core/services/websocket.service';
import { ChartSnapRequest, ChartWatchRequest, LogInMessage, NewsRequest } from '@px-core/models/messages.model';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { StorageService } from '@px-core/services/storage.service';

@Injectable()
export class ChartsService {

  private chartSnap = new Subject<any>();
  private chartWatch = new Subject<any>();
  private addSymbolsOnChart = new Subject<any>();
  private removeSymbolsOnChart = new Subject<any>();
  private symbolsOnChart = ['@W@1', '@C@1', '@W@1', '@S@1', '@MW@1'];

  constructor(private webSocketService: WebsocketService, private storageService: StorageService) {
    this.webSocketService.getWebSocketMessage().subscribe(({ data }) => {
      if (data.meta.command.toLowerCase() === 'chartsnap' ||
        data.meta.command.toLowerCase() === 'chartwatch') {
        this.onNext(data);
      }
    });
  }

  loadChartSnap(request: ChartSnapRequest) {
    this.webSocketService.send(request);
  }

  loadChartWatch(request: ChartWatchRequest) {
    this.webSocketService.send(request);
  }

  onNext(message: any) {
    if (message.meta.command.toLowerCase() === 'chartsnap') {
      this.chartSnap.next(message);
    }
    if (message.meta.command.toLowerCase() === 'chartwatch') {
      this.storageService.setWatchChart(message.meta);
      this.chartWatch.next(message);
    }
  }

  getChartSnap(): Observable<any> {
    return this.chartSnap.asObservable();
  }

  getChartWatch(): Observable<any> {
    return this.chartWatch.asObservable();
  }

  addSymbolOnChart(expression, type) {
    this.symbolsOnChart.push(expression);
    this.addSymbolsOnChart.next({ expression, type });
  }

  removeSymbolFromChart(expression) {
    this.symbolsOnChart = this.symbolsOnChart.filter(e => e !== expression);
    this.removeSymbolsOnChart.next({ expression });
  }

  getSymbolsOnChart() {
    return this.symbolsOnChart;
  }

  listenForSymbolAdded(): Observable<any> {
    return this.addSymbolsOnChart.asObservable();
  }

  listenForSymbolRemoved(): Observable<any> {
    return this.removeSymbolsOnChart.asObservable();
  }
}
