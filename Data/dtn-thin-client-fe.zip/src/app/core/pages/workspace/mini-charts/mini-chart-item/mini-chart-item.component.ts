import { AfterViewInit, Component, ElementRef, Input, OnInit, OnDestroy } from '@angular/core';
import { ChartTick } from '@px-core/models/chart-tick.model';
import { ChartsService } from '@px-core/services/charts.service';
import { ChartWatchRequest, ChartSnapRequest } from '@px-core/models/messages.model';
import { QuoteService } from '@px-core/services/quote.service';
import { Chart } from 'chart.js';
import { StorageService } from '@px-core/services/storage.service';
import { Subscription } from 'rxjs/Subscription';
import { ThrottleRequestService } from '@px-core/services/throttle-request.service';
import * as faker from 'faker';

@Component({
  selector: 'app-mini-chart-item',
  templateUrl: './mini-chart-item.component.html',
  styleUrls: ['./mini-chart-item.component.scss']
})
export class MiniChartItemComponent implements OnInit, AfterViewInit, OnDestroy {

  @Input() expression;
  @Input() index;
  chartTick: ChartTick;
  chartTicks: ChartTick[];
  closeValues;
  requestId: string;
  chart = [];
  private subscriptionWatch: Subscription;
  private subscriptionSnap: Subscription;


  constructor(private chartService: ChartsService,
              private quoteService: QuoteService,
              private storageService: StorageService,
              private throttleRequestService: ThrottleRequestService) {
  }

  ngOnInit() {
    this.requestId = faker.random.uuid();
    let request;
    if (this.storageService.getRefreshInterval() !== 0) {
      request = new ChartWatchRequest(this.requestId, this.expression, 100, 'SECOND', 1, this.storageService.getRefreshInterval());
      this.chartService.loadChartWatch(request);
    } else {
      request = new ChartSnapRequest(this.requestId, this.expression, 100, 'SECOND', 1);
      this.chartService.loadChartSnap(request);
    }

    this.subscriptionWatch = this.chartService.getChartWatch().subscribe(message => {
      if (message !== undefined) {
        if (message.meta.requestId === this.requestId && message.data !== undefined) {

          this.chartTick = message.data[0];
          this.chartTicks = message.data;
          this.closeValues = message.data.map(tick =>
            tick.Close
          );
          this.addChartData(this.chart, this.closeValues);

        }
      }
    });

    this.subscriptionSnap = this.chartService.getChartSnap().subscribe(message => {
      if (message !== undefined) {
        if (message.meta.requestId === this.requestId && message.data !== undefined) {

          this.chartTick = message.data[0];
          this.chartTicks = message.data;
          this.closeValues = message.data.map(tick =>
            tick.Close
          );
          this.addChartData(this.chart, this.closeValues);

        }
      }
    });

  }

  ngAfterViewInit() {

    this.initChart();

  }

  ngOnDestroy(): void {
    this.subscriptionWatch.unsubscribe();
    this.subscriptionSnap.unsubscribe();
    this.throttleRequestService.unwatch(false);
  }

  initChart() {
    this.chart = new Chart('chart' + this.index, {
      type: 'line',
      data: {
        labels: [12, 6, 12, 6, 12],
        datasets: [{
          data: [],
          label: this.expression,
          borderColor: '#1CB05F',
          fill: false
        }]
      },
      options: {
        title: {
          display: false,
          text: 'Last price of ' + this.expression
        },
        legend: {
          display: false,
        },
        tooltips: {
          callbacks: {
            label: tooltipItem => `${tooltipItem.yLabel}: ${tooltipItem.xLabel}`,
            title: () => null,
          }
        },
      }
    });
  }

  addChartData(chart, data) {
    chart.data.datasets.forEach((dataset) => {

      data.forEach(function (value) {
        dataset.data.push(value.number);
      });

      if (dataset.data.length > 9) {
        dataset.data.shift();
      }
    });
    chart.update();
  }
}
