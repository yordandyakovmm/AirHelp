import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiddleChartsComponent } from './middle-charts.component';

describe('MiddleChartsComponent', () => {
  let component: MiddleChartsComponent;
  let fixture: ComponentFixture<MiddleChartsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiddleChartsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiddleChartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
