import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { WebSocketMessage } from '@px-core/models/messages.model';
/**
 * TODO: Handle server shutdown (i.e. 'ServerShutdown')
 * remove all console.logs
 */

@Injectable()
export class WebsocketService {

  webSocketInstance: any;
  message: WebSocketMessage;
  isConnected: Boolean = false;
  webSocketResponse = new Subject<any>();

  connect(message: WebSocketMessage): void {
    // console.log(environment);
    this.message = message;
    this.webSocketInstance = new WebSocket(environment.wsBaseUrl);
    this.webSocketInstance.onopen = (res) => {
      this.onOpen(res);
    };
    this.webSocketInstance.onclose = (res) => {
      this.onClose(res);
    };
    this.webSocketInstance.onmessage = (res) => {
      this.onMessage(res);
    };
    this.webSocketInstance.onerror = (res) => {
      this.onError(res);
    };
  }

  send(message: WebSocketMessage) {
    if (this.webSocketInstance.readyState === 1) {
      this.webSocketInstance.send(JSON.stringify(message));
    }
  }

  disconnect() {
    this.webSocketInstance.close();
  }

  ///////////////////////////////////////
  // BEGIN Websocket Generic handlers: //
  ///////////////////////////////////////
  onOpen(res: any): void {
    // console.log('open', arguments);
    // console.log(this.message);
    this.isConnected = true;
    this.webSocketInstance.send(JSON.stringify(this.message));
  }

  onMessage(payload): void {
    // Handle server push
    // Handle the server status in separate service with command 'status'
    const message = JSON.parse(payload.data);
    // console.log(payload);
    this.webSocketResponse.next({ data: message });
  }

  onError(res): void {
    console.warn('error', res);
  }

  onClose(res): void {
    // console.log('close', res);
    switch (res.code) {
      case 1006:
        this.webSocketResponse.next({
          data: {
            meta: { command: 'Login' },
            errors: [{ code: res.code, detail: 'Network Error: No Network Connection.' }]
          }
        });
        break;
    }
  }

  /////////////////////////////////////
  // END Websocket Generic handlers: //
  /////////////////////////////////////

  getWebSocketMessage(): Observable<any> {
    return this.webSocketResponse.asObservable();
  }

}
