import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthUserService } from '@px-core/services/auth-user.service';
import { Router } from '@angular/router';
import { LogInMessage } from '@px-core/models/messages.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  form: FormGroup;
  passwordFieldType: String = 'password';
  formHasErrors: Boolean = false;
  wsErrors: any = null;

  constructor(private fb: FormBuilder,
              private authUserService: AuthUserService,
              private router: Router) {
    this.form = fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }

  ngOnInit() {
    if (this.authUserService.forcedLogout) {
      this.wsErrors = this.authUserService.forcedLogout.errors;
    }
    this.authUserService.getAuthUser().subscribe(({ data }) => {
      if (data.errors) {
        this.wsErrors = data.errors;
      } else {
        this.form.reset();
        this.router.navigate(['/workspaces']);
      }
    });

    // TODO: REMOVE THIS LOCALSTORAGE LOGIN ON PROD
    if (localStorage.getItem('username') && localStorage.getItem('password')) {
      this.authUserService.authenticate(localStorage.getItem('username'), localStorage.getItem('password'));
    }
    // TODO: REMOVE THIS LOCALSTORAGE LOGIN ON PROD
  }

  onLogIn() {
    if (!this.form.invalid) {
      this.formHasErrors = false;
      this.passwordFieldType = 'password';
      const { username, password } = this.form.controls;
      this.authUserService.authenticate(username.value, password.value);
    } else {
      this.formHasErrors = true;
    }
  }

  togglePasswordField() {
    if (this.passwordFieldType === 'password') {
      this.passwordFieldType = 'text';
    } else {
      this.passwordFieldType = 'password';
    }
  }
}
