import { Component, OnInit } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { AuthUserService } from '@px-core/services/auth-user.service';
import { Router } from '@angular/router';
import { ConfirmDialog } from '../confirm-dialog/confirm.dialog';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ConfirmDialogModel } from '@px-core/models/dialogs.model';
import { StorageService } from '@px-core/services/storage.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})

export class NavbarComponent implements OnInit {
  hasAuthenticated: Boolean;
  isUserButtonClicked: Boolean = false;
  isConnected: Boolean = true;

  constructor(private router: Router,
              private authUserService: AuthUserService,
              private dialog: MatDialog,
              private storageService: StorageService) {
              this.hasAuthenticated = this.authUserService.isAuthenticated;
  }

  onUserButtonClicked() {
    this.isUserButtonClicked = !this.isUserButtonClicked;
  }

  ngOnInit() {
  }

  watchForConnectionToDtnMarketServer() {
    // just for test
    this.isConnected = !this.isConnected;
  }

  onLogOut() {
    const dialogRef = this.dialog.open(ConfirmDialog, {
      panelClass: 'custom-dialog',
      width: '340px',
      position: { top: '193px'},
      data: new ConfirmDialogModel('LOG OUT', 'Are you sure you want to log out?', { cancel: 'Cancel', ok: 'Yes'})
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.storageService.clearWatchQuotes();
        this.authUserService.logOut();
        this.router.navigate(['/login']);
      }
    });
  }

}
