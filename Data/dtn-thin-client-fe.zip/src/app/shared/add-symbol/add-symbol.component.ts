import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { SymbolSearchService } from '@px-core/services/symbol-search.service';
import { StorageService } from '@px-core/services/storage.service';

@Component({
  selector: 'app-add-symbol',
  templateUrl: './add-symbol.component.html',
  styleUrls: ['./add-symbol.component.scss']
})
export class AddSymbolComponent implements OnInit {
  addSymbolForm: FormGroup;
  symbols: any = [];
  toggledSymbolsInGroup: any = {};
  toggledGroups: any = {};
  groupOptions: Array<String> = [];
  @Output() addSymbolStateChange: EventEmitter<any> = new EventEmitter<any>();

  constructor(private fb: FormBuilder, private symbolSearchService: SymbolSearchService, private storageService: StorageService) {
    this.addSymbolForm = this.fb.group({
      search: [''],
      symbols: this.fb.array([])
    });
    this.symbolSearchService.getSearchResults().subscribe(({ data }) => {
      if (data.errors) {
        this.symbols = [];
      } else {
        this.symbols = [...data.data];
      }
    });
    this.storageService.getQuoteList().map(element => {
      if (element.group) {
        this.groupOptions.push(element.group);
      }
    });
  }

  ngOnInit() {
  }

  initSymbols(symbol, uniqueStamp) {
    return this.fb.group({
      symbol: [symbol],
      group: [''],
      hasGroup: [false],
      uniqueStamp: [uniqueStamp]
    });
  }

  addSymbol(symbol) {
    const control = <FormArray>this.addSymbolForm.controls['symbols'];
    const uniqueStamp = Date.now().toString();
    control.push(this.initSymbols(symbol, uniqueStamp));
    this.toggledSymbolsInGroup[uniqueStamp] = false;
    this.toggledGroups[uniqueStamp] = false;
    this.onFormStateChange();
  }

  removeSymbol(index, uniqueStamp) {
    const control = <FormArray>this.addSymbolForm.controls['symbols'];
    control.removeAt(index);
    delete this.toggledSymbolsInGroup[uniqueStamp];
    delete this.toggledGroups[uniqueStamp];
    this.onFormStateChange();
  }

  onSearchChange() {
    if (this.addSymbolForm.controls['search'].value) {
      this.symbolSearchService.searchForSymbol(this.addSymbolForm.controls['search'].value);
    }
  }

  onSymbolSelected(symbol) {
    this.addSymbolForm.controls['search'].setValue('');
    this.addSymbol(symbol);
  }

  toggleSymbolInGroup(uniqueStamp, index) {
    this.toggledSymbolsInGroup[uniqueStamp] = !this.toggledSymbolsInGroup[uniqueStamp];
    if (!this.toggledSymbolsInGroup[uniqueStamp]) {
      this.addSymbolForm.controls['symbols']['controls'][index].controls.group.setValue('');
      this.toggledGroups[uniqueStamp] = false;
    }
  }

  toggleGroupOptions(uniqueStamp) {
    this.toggledGroups[uniqueStamp] = !this.toggledGroups[uniqueStamp];
  }

  onGroupSelect(group, index, uniqueStamp) {
    this.addSymbolForm.controls['symbols']['controls'][index].controls.group.setValue(group);
    this.toggledGroups[uniqueStamp] = false;
    this.onFormStateChange();
  }

  onFormStateChange() {
    const state = this.addSymbolForm.controls['symbols']['controls'].map(el => {
      const symbol = {};
      Object.keys(el.controls).forEach(key => {
        symbol[key] = el.controls[key].value;
      });
      return symbol;
    });
    this.addSymbolStateChange.emit(state);
  }
}
