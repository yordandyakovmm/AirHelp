import { Component, OnInit, HostListener } from '@angular/core';

@Component({
  selector: 'app-layout-workspace',
  templateUrl: './layout-workspace.component.html',
  styleUrls: ['./layout-workspace.component.scss']
})
export class LayoutWorkspaceComponent implements OnInit {
  @HostListener('window:beforeunload', ['$event']) onHover($event) {
    $event.returnValue = 'Your session won\'t be saved.';
    return 'Your session won\'t be saved.';
  }

  constructor() {}

  ngOnInit() {
  }

}
