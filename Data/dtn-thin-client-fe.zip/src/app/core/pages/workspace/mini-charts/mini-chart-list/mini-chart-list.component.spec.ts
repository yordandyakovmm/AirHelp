import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiniChartListComponent } from './mini-chart-list.component';

describe('MiniChartListComponent', () => {
  let component: MiniChartListComponent;
  let fixture: ComponentFixture<MiniChartListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiniChartListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiniChartListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
