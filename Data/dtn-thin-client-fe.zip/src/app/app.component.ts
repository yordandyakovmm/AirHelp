import { Component, OnInit, OnDestroy } from '@angular/core';
import { StorageService } from '@px-core/services/storage.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnDestroy {
  isLightTheme: Boolean;
  constructor(private storageService: StorageService) {
    if (!this.storageService.checkForStorage()) {
      this.storageService.initStorage(this.storageService.fields);
    }
    this.isLightTheme = !this.storageService.getTheme();
  }

  ngOnDestroy(): void {
    this.storageService.clearWatchQuotes();
    this.storageService.clearWatchCharts();
  }
}
