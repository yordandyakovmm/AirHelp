export class WebSocketMessage {
  meta: any;
  data: any;

  constructor(meta: any, data: any) {
    this.meta = meta;
    this.data = data;
  }
}

export class LogInMessage extends WebSocketMessage {
  constructor(username: string, password: string) {
    const data = { username, password, appname: 'ThinClient', version: '0.2.0' };
    super({ command: 'Login' }, data);
  }
}

export class ChartSnapRequest extends WebSocketMessage {

  constructor(private requestId: string,
    private expression: string,
    limit: number,
    interval: string,
    intervalCount: number) {
    super({
      command: 'ChartSnap',
      requestId: requestId
    }, {
        expression: expression,
        limit: limit,
        interval: interval,
        intervalCount: intervalCount,
        priceFormat: 'dict',
      });
  }
}

export class ChartWatchRequest extends WebSocketMessage {
  constructor(private requestId: string,
    private expression: string,
    limit: number,
    interval: string,
    intervalCount: number,
    updateInterval) {
    super({
      command: 'ChartWatch',
      requestId: requestId
    }, {
        expression: expression,
        limit: limit,
        interval: interval,
        intervalCount: intervalCount,
        updateInterval: updateInterval,
        priceFormat: 'dict',
      });
  }
}

export class NewsRequest extends WebSocketMessage {

  constructor() {
    super({
      'command': 'NewsWatch',
      'requestId': 3
    }, {
        'query': 'solar',
        'limit': 100,
        'location': 'all',
        'source': 'DTN',
        'timeFormat': 'text'
      });
  }
}


export class QuoteWatchRequest extends WebSocketMessage {

  constructor(private requestId: string, private expression: string, private fields: [string], private updateInterval?: number) {
    super({
      'command': 'QuoteWatch',
      requestId
    }, {
        expression,
        fields,
        'priceFormat': 'text',
        updateInterval,
      });
  }
}

export class QuoteSnapRequest extends WebSocketMessage {

  constructor(private requestId: string, private expression: string, private fields: [string]) {
    super({
      'command': 'QuoteSnap',
      requestId
    }, {
        expression,
        fields,
        'priceFormat': 'text',
      });
  }
}

export class ThrottleChangeRequest extends WebSocketMessage {

  constructor(updateInterval: Number) {
    super({
      command: 'ThrottleChange',
      requestId: ''
    }, {
        updateInterval: updateInterval
      });
  }
}

export class UnwatchRequest extends WebSocketMessage {

  constructor(requestId) {
    super({
      command: 'Unwatch',
      requestId: requestId
    }, {});
  }
}

export class SymbolSearchRequest extends WebSocketMessage {

  constructor(symbol: String) {
    super({
      command: 'SymbolSearch',
      requestId: ''
    }, {
        sympat: `${symbol}*`,
        limit: 8,
        symbolFormat: 'dict'
      });
  }
}


