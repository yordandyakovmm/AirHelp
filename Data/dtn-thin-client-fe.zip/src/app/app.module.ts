import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { CoreModule } from '@px-core/core.module';
import { SharedModule } from '@px-shared/shared.module';
import { AppComponent } from './app.component';
import { SortablejsModule } from 'angular-sortablejs';

// if we need to support animations include this module
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material.module';
import { AppRoutingModule } from './app.routing.module';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    CoreModule,
    MaterialModule,
    NoopAnimationsModule,
    AppRoutingModule,
    SortablejsModule.forRoot({ animation: 0 }),
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
