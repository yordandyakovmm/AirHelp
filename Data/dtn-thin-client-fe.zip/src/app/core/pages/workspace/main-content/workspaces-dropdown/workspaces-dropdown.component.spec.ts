import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkspacesDropdownComponent } from './workspaces-dropdown.component';

describe('WorkspacesDropdownComponent', () => {
  let component: WorkspacesDropdownComponent;
  let fixture: ComponentFixture<WorkspacesDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkspacesDropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkspacesDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
