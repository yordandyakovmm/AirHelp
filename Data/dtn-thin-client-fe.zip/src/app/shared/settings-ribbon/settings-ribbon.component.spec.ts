import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SettingsRibbonComponent } from './settings-ribbon.component';

describe('SettingsRibbonComponent', () => {
  let component: SettingsRibbonComponent;
  let fixture: ComponentFixture<SettingsRibbonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SettingsRibbonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SettingsRibbonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
