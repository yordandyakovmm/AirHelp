import { AfterViewInit, Component, Input, OnDestroy, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts/highstock';
import * as SimpleHighcharts from 'highcharts';
import * as Exporting from 'highcharts/modules/exporting';
import { ChartTick } from '@px-core/models/chart-tick.model';
import { ChartWatchRequest, ChartSnapRequest } from '@px-core/models/messages.model';
import { ChartsService } from '@px-core/services/charts.service';
import { StorageService } from '@px-core/services/storage.service';
import * as moment from 'moment';
import * as $ from 'jquery';
import * as faker from 'faker';
import { Subscription } from 'rxjs/Subscription';
import { ThrottleRequestService } from '@px-core/services/throttle-request.service';
import { Subject } from "rxjs/Subject";
import { LoadingSettingsService } from '@px-core/services/loading-settings.service';

@Component({
  selector: 'app-middle-chart-item',
  templateUrl: './middle-chart-item.component.html',
  styleUrls: ['./middle-chart-item.component.scss']
})
export class MiddleChartItemComponent implements OnInit, AfterViewInit, OnDestroy {

  @Input() expression;
  @Input() index;
  chartTicks: ChartTick[];
  lastChartTick: ChartTick;
  currentIndicator;
  deltaIndicator: string = 'same';
  closePriceDifference: number = 0.00;
  requestId: string;
  chart;
  isInitialChartDraw: boolean = true;
  quoteData;
  showSettingsOptions: boolean = false;
  private subscriptionWatch: Subscription;
  private subscriptionSnap: Subscription;

  constructor(private chartService: ChartsService,
              private storageService: StorageService,
              private throttleRequestService: ThrottleRequestService,
              private loadingSettingsService: LoadingSettingsService) {
  }

  ngOnInit() {

    if (this.storageService.quoteListSymbols[this.expression] === undefined) {
      this.storageService.quoteListSymbols[this.expression] = new Subject();
    }

    this.storageService.quoteListSymbols[this.expression].subscribe((data) => {
      this.quoteData = data;
    });

    this.requestId = faker.random.uuid();
    let request;
    if (this.storageService.getRefreshInterval() !== 0) {
      request = new ChartWatchRequest(this.requestId, this.expression, 100, 'DAY', 1, this.storageService.getRefreshInterval());
      this.chartService.loadChartWatch(request);
    } else {
      request = new ChartSnapRequest(this.requestId, this.expression, 100, 'DAY', 1);
      this.chartService.loadChartSnap(request);
    }
  }

  ngAfterViewInit() {
    Exporting(Highcharts);
    Exporting(SimpleHighcharts);

    this.initChart(this.expression);
    this.initChartWatchSubscriber();
  }


  ngOnDestroy() {
    this.subscriptionSnap.unsubscribe();
    this.subscriptionWatch.unsubscribe();
    this.throttleRequestService.unwatchRequest(this.requestId);

    this.currentIndicator = {};
  }

  /**
   * Initialize and configure the chart in this component
   * @param {string} selector
   */
  initChart(selector: string) {

    const expression = this.expression;

    /***************** PUT IN OWN FILE FOR REUSE *****************/
    this.currentIndicator = {
      value: -10,
      deltaInd: 'same',
      delta: 0,
      render: function (chart) {
        let $H = Highcharts,
          merge = $H.merge,
          priceYAxis = chart.yAxis[0],
          priceSeries = chart.series[0],
          priceData = priceSeries.yData,
          currentPrice = (priceData[priceData.length - 1] === undefined) ? 0.00 : priceData[priceData.length - 1],
          extremes = priceYAxis.getExtremes(),
          min = extremes.min,
          max = extremes.max,
          options = chart.options.yAxis[0].currentOptions,
          defaultOptions = {
            backgroundColor: '#313131',
            borderColor: '#313131',
            color: {
              same: '#313131',
              up: '#1ab15d',
              down: '#fc4a3e'
            },
            enabled: true,
            style: {
              color: '#ffffff',
              fontSize: '.75rem'
            },
            x: 0,
            y: 0,
            zIndex: 1
          },
          chartWidth = chart.chartWidth,
          chartHeight = chart.chartHeight,
          marginRight = chart.optionsMarginRight || 0,
          marginLeft = chart.optionsMarginLeft || 0,
          renderer = chart.renderer,
          currentChartIndicator = priceYAxis.currentChartIndicator || {},
          isRendered = Object.keys(currentChartIndicator).length,
          group = currentChartIndicator.group,
          label = currentChartIndicator.label,
          box = currentChartIndicator.box,
          triangle = currentChartIndicator.triangle,
          width,
          height,
          path,
          x, y;
        options = merge(true, defaultOptions, options);

        width = priceYAxis.opposite ? (marginRight ? marginRight : 45) : (marginLeft ? marginLeft : 45);
        x = priceYAxis.opposite ? chartWidth - width : marginLeft;
        y = (currentPrice === 0) ? 0 : priceYAxis.toPixels(currentPrice);

        x += options.x;
        y += options.y;


        if (parseFloat(this.delta) > parseFloat('0')) {
          this.deltaInd = 'up';
        } else if (parseFloat(this.delta) < parseFloat('0')) {
          this.deltaInd = 'down';
        } else {
          this.deltaInd = 'same';
        }

        if (options.enabled) {
          if (!isRendered) {
            group = renderer.g().attr({
              zIndex: options.zIndex
            }).add();

            label = renderer.text(currentPrice.toFixed(2), x, y).attr({
              zIndex: 5001
            }).css({
              color: options.style.color,
              fontSize: options.style.fontSize,
              'z-index': 5001
            }).add(group);

            height = label.getBBox().height;
            path = ['M', x - 8, y, 'L', x - 2, y - (height / 2), 'L', x - 2, y + (height / 2), 'z'];

            box = renderer.rect(x, y - (height / 2), width, height).attr({
              fill: options.color.no,
              stroke: options.color.no,
              zIndex: 5000,
              'stroke-width': 1
            }).add(group);

            triangle = renderer.path(path).attr({
              fill: options.color.no,
              stroke: options.color.no,
              zIndex: 5000,
            }).add(group);

            label.animate({
              y: y + (height / 4)
            }, 0);
          } else {
            currentChartIndicator.label.animate({
              text: currentPrice.toFixed(2),
              y: y
            }, 0);

            height = currentChartIndicator.label.getBBox().height;
            path = ['M', x - 13, y, 'L', x - 3, y - (height / 2), 'L', x - 3, y + (height / 2), 'z'];

            $.each(priceYAxis.currentChartIndicator.group.element.children, function (index) {

              let _el = $(priceYAxis.currentChartIndicator.group.element.children[index]);

              if (_el[0] !== undefined && _el[0].tagName.toLowerCase() === 'path') {
                $(_el).remove();
              }

            });

            currentChartIndicator.triangle = renderer.path(path).attr({
              fill: options.color[this.deltaInd],
              stroke: options.color[this.deltaInd],
              zIndex: 5000
            }).add(group);

            currentChartIndicator.box.animate({
              fill: options.color[this.deltaInd],
              stroke: options.color[this.deltaInd],
              x: x - 4,
              y: y - (height / 2)
            }, 0);

            currentChartIndicator.label.animate({
              x: x - 4,
              y: y + (height / 4)
            }, 0);
          }

          if (currentPrice > min && currentPrice < max) {
            group.show();
          } else {
            group.hide();
          }

          // register to price y-axis object
          priceYAxis.currentChartIndicator = {
            group: group,
            label: label,
            box: box,
            triangle: triangle
          };
        }
      }
    };
    /***************** PUT IN OWN FILE FOR REUSE *****************/

    const merge = SimpleHighcharts.merge;
    const currentIndicator = this.currentIndicator;

    SimpleHighcharts.wrap(SimpleHighcharts.Chart.prototype, 'redraw', function (redraw) {
      // Call the original method
      redraw.apply(this, Array.prototype.slice.call(arguments, 1));
      currentIndicator.render(this);
    });

    this.chart = SimpleHighcharts.chart(selector, {
      chart: {
        backgroundColor: '#2C2C2C',
        reflow: true,
        events: {
          load: function () {
            let series = this.series[0],
              len = series.data.length;
            let last = (len === 0) ? 0 : series.data[len - 1].y;

            currentIndicator.value = Number(last.toFixed(2));
            currentIndicator.render(this);
          },
          click: function (e) {

            this.xAxis[0].crosshair = !this.xAxis[0].crosshair;
            this.yAxis[0].crosshair = !this.yAxis[0].crosshair;

            this.redraw();

          }
        }
      },
      colors: ['#b1b1b1'],
      yAxis: {
        opposite: true,
        gridLineColor: '#4E4E4E',
        title: {
          text: '',
        },
        type: 'logarithmic',
        labels: {
          formatter: function () {
            return this.value.toFixed(2);
          },
          useHTML: false,
          align: 'left',
          x: 20,
          style: {
            color: '#818485',
            'z-index': 1
          },
          zIndex: 1
        },
        zIndex: 1,
      },
      xAxis: {
        tickColor: '#2C2C2C',
        lineColor: '#4E4E4E',
        type: 'datetime',
        labels: {
          style: {
            fontSize: 14,
            color: '#818485',
          },
        },
      },
      rangeSelector: {
        selected: 1
      },

      title: {
        text: '',
        enabled: false,
      },
      legend: {
        enabled: false,
      },

      plotOptions: {
        series: {
          marker: {
            enabled: false
          }
        }
      },

      series: [{
        data: [],
        lineWidth: 4,
        lineColor: '#b2b2b2',
        tooltip: {
          valueDecimals: 2
        }
      }],
      exporting: {
        enabled: false,
      },
      credits: {
        enabled: false,
      },
      tooltip: {
        valueDecimals: 2,
        formatter: function () {
          return expression + '<br />' +
            moment.utc(this.point.x).format('MM/DD/YYYY HH:mm:ss') + '<br />' +
            'Close: ' + this.point.name + '<br />';
        }
      },
      loading: this.loadingSettingsService.loadingSettings
    });

    // init loading
    this.chart.showLoading(' ');
  }

  /**
   * Subscribe to the ChartWatch command on the selected symbol
   */
  initChartWatchSubscriber() {
    this.subscriptionWatch = this.chartService.getChartWatch().subscribe(message => {
      if (message !== undefined) {
        if (message.meta.requestId === this.requestId && message.data !== undefined) {

          this.chartTicks = message.data;

          let data = [];
          this.chartTicks.forEach(tick => {
            const tickDate = Number(moment(tick.DateTime).format('X')) * 1000;

            data.push({ name: tick.Close.text, x: tickDate, y: tick.Close.number });
          });

          let lastDataItem = data[data.length - 1];

          if (this.lastChartTick && data.length > 0) {

            let lastChartTickClose: number = this.lastChartTick.Close.number;
            let lastDataClose: number = lastDataItem.y;

            this.closePriceDifference = (lastDataClose - lastChartTickClose);

          }

          this.lastChartTick = message.data[message.data.length - 1];

          this.addChartData(this.chart, data);

        }
      }
    });

    this.subscriptionSnap = this.chartService.getChartSnap().subscribe(message => {
      if (message !== undefined) {
        if (message.meta.requestId === this.requestId && message.data !== undefined) {

          this.chartTicks = message.data;

          let data = [];
          this.chartTicks.forEach(tick => {

            const tickDate = Number(moment.utc(tick.DateTime).format('X')) * 1000;

            data.push({ name: tick.Close.text, x: tickDate, y: tick.Close.number });
          });

          let lastDataItem = data[data.length - 1];

          if (this.lastChartTick && data.length > 0) {

            let lastChartTickClose: number = this.lastChartTick.Close.number;
            let lastDataClose: number = lastDataItem.y;

            this.closePriceDifference = (lastDataClose - lastChartTickClose);

          }

          this.lastChartTick = message.data[message.data.length - 1];

          this.addChartData(this.chart, data);

        }
      }
    });
  }

  addChartData(chart, data) {

    let _tmpYData = 0;

    data.forEach(item => {

      let pushData: boolean = false;


      if (chart.series[0].data.length >= 100) {
        pushData = true;
      }

      if (chart.series[0].data.length > 0) {
        let lastDate = chart.series[0].data[chart.series[0].data.length - 1].x;
        _tmpYData = chart.series[0].data[chart.series[0].data.length - 1].y;

        if (lastDate !== item.x) {
          chart.series[0].addPoint(item, false, pushData);
        } else {
          chart.series[0].data[chart.series[0].data.length - 1].update({ y: item.y });
        }

      } else {
        chart.series[0].addPoint(item, false, pushData);
      }

    });

    let y = data[data.length - 1].y;


    this.currentIndicator.value = y.toFixed(2);
    const last = (chart.series[0].data.length > 0) ? chart.series[0].data[chart.series[0].data.length - 1].y : 0.00;


    this.currentIndicator.delta = Number((y - _tmpYData).toFixed(2));

    if (this.isInitialChartDraw) {
      this.currentIndicator.delta = 0;
      this.isInitialChartDraw = false;
    }


    chart.redraw();
    chart.reflow();
    chart.hideLoading();
    this.currentIndicator.render(chart);

    if (parseFloat(this.currentIndicator.delta) < parseFloat('0')) {
      this.deltaIndicator = 'down';
    } else if (parseFloat(this.currentIndicator.delta) > parseFloat('0')) {
      this.deltaIndicator = 'up';
    } else {
      this.deltaIndicator = 'same';
    }

  }

  showSettings() {
    this.showSettingsOptions = !this.showSettingsOptions;
  }
}
