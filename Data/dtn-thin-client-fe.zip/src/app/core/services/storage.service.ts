import { Injectable } from '@angular/core';
import * as faker from 'faker';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class StorageService {
  public fields = [
    'IssueDescription',
    'Last',
    'Change',
    'High',
    'Low',
    'Open',
    'Bid',
    'Ask',
    'Volume',
    'OpenInterest',
    'Volatility',
    'BidSize',
    'AskSize'
  ];

  quoteListSymbols = {
  };

  constructor() {
  }

  initStorage(fields) {
    const refreshInterval = 1;

    const quoteList: any = [
      {
        group: 'QA',
        symbols: [
          {
            expression: '@C@A',
            fields
          },
          {
            expression: 'QCL@A',
            fields
          },
        ]
      },
      {
        group: 'US AG',
        symbols: [{
          expression: '@C@1',
          fields,
        }, {
          expression: '@W@1',
          fields,
        }, {
          expression: '@MW@1',
          fields,
        },
        {
          expression: '@S@1',
          fields,
        }, {
          expression: '@S@1',
          fields,
        }, {
          expression: '@SM@1',
          fields,
        }, {
          expression: '@BO@1',
          fields,
        }, {
          expression: '@RR@1',
          fields,
        }, {
          expression: '@KC@1',
          fields,
        }, {
          expression: '@SB@1',
          fields,
        }, {
          expression: '@CC@1',
          fields,
        }, {
          expression: '@CT@1',
          fields,
        }, {
          expression: '@SB@1',
          fields,
        }, {
          expression: '@CC@1',
          fields,
        }, {
          expression: '@CT@1',
          fields,
        }, {
          expression: '@OJ@1',
          fields,
        }, {
          expression: '@OJ@1',
          fields,
        }, {
          expression: '@LE@1',
          fields,
        }, {
          expression: '@GF@1',
          fields,
        },
        {
          expression: '@HE@1',
          fields,
        }
        ]
      },
      {
        group: 'US ENERGY',
        symbols: [{
          expression: 'QCL@1',
          fields,
        },
        {
          expression: 'QRB@1',
          fields,
        }, {
          expression: 'QHO@1',
          fields,
        }, {
          expression: 'QNG@1',
          fields,
        }, {
          expression: '@AC@1',
          fields,
        }
        ]
      },
      {
        group: 'US STOCK MARKET',
        symbols: [{
          expression: 'INDU.X',
          fields,
        }, {
          expression: 'COMPX.X',
          fields,
        }, {
          expression: 'INX.X',
          fields,
        }]
      },
      {
        group: 'CURRENCIES',
        symbols: [{
          expression: '@EU@1',
          fields,
        }, {
          expression: '@BP@1',
          fields,
        }, {
          expression: '@JY@1',
          fields,
        }, {
          expression: '@CD@1',
          fields,
        }, {
          expression: '@SF@1',
          fields,
        }, {
          expression: '@AD@1',
          fields,
        }]
      },
      {
        group: 'US METALS',
        symbols: [{
          expression: 'QGC@1',
          fields,
        }, {
          expression: 'QSI@1',
          fields,
        }, {
          expression: 'QHG@1',
          fields,
        }, {
          expression: 'QPL@1',
          fields,
        }, {
          expression: 'QPA@1',
          fields,
        }]
      },
      {
        group: 'TREASURY',
        symbols: [{
          expression: '@TU@1',
          fields,
        }, {
          expression: '@FV@1',
          fields,
        }, {
          expression: '@US@1',
          fields,
        }]
      },
      {
        group: 'WORLD',
        symbols: [{
          expression: 'CA@1',
          fields,
        }, {
          expression: 'PM@1',
          fields,
        }, {
          expression: 'QK@1',
          fields,
        }, {
          expression: 'WAW@1',
          fields,
        }, {
          expression: 'PG@1',
          fields,
        }, {
          expression: 'LRC@1',
          fields,
        }, {
          expression: 'QW@1',
          fields,
        }, {
          expression: 'KPO@1',
          fields,
        }, {
          expression: 'EB@1',
          fields,
        }, {
          expression: 'GAS@1',
          fields,
        }, {
          expression: 'GX@1',
          fields,
        }, {
          expression: 'XG@1',
          fields,
        }, {
          expression: 'MT@1',
          fields,
        }, {
          expression: 'LF@1',
          fields,
        }, {
          expression: 'SPI@1',
          fields,
        }, {
          expression: 'LF@1',
          fields,
        }, {
          expression: 'BD@1',
          fields,
        }, {
          expression: 'BL@1',
          fields,
        }, {
          expression: 'EZ@1',
          fields,
        }, {
          expression: 'JG@1',
          fields,
        }]
      },
      {
        group: '',
        symbols: []
      }
    ];

    quoteList.forEach(group => {
      group.symbols.forEach(symbol => {
        symbol.requestId = faker.random.uuid();
      });

    });

    localStorage.setItem('settings', JSON.stringify({
      refreshInterval,
      watchQuotes: [],
      watchCharts: [],
      getNotPermittedQuotes: [],
      quoteList,
      darkTheme: true
    }));
  }

  checkForStorage() {
    return localStorage.getItem('settings') ? true : false;
  }

  getRefreshInterval() {
    return JSON.parse(localStorage.getItem('settings')).refreshInterval;
  }

  setRefreshInterval(refreshInterval: Number) {
    const newState = { ...JSON.parse(localStorage.getItem('settings')), refreshInterval };
    localStorage.setItem('settings', JSON.stringify(newState));
  }

  getWatchQuotes() {
    return JSON.parse(localStorage.getItem('settings')).watchQuotes;
  }

  setWatchQuote(newQuote: any) {
    const newState = JSON.parse(localStorage.getItem('settings'));
    if (!newState.watchQuotes.find(q => q.requestId === newQuote.requestId) && newQuote.status === 200) {
      newState.watchQuotes.push(newQuote);
      localStorage.setItem('settings', JSON.stringify(newState));
    }

    if (!newState.getNotPermittedQuotes.find(q => q.requestId === newQuote.requestId) && newQuote.status === 401) {
      newState.getNotPermittedQuotes.push(newQuote);
      localStorage.setItem('settings', JSON.stringify(newState));
    }
  }

  getNotPermittedQuotes() {
    return JSON.parse(localStorage.getItem('settings')).getNotPermittedQuotes;
  }

  clearWatchQuotes() {
    const newState = JSON.parse(localStorage.getItem('settings'));
    newState.watchQuotes = [];
    newState.getNotPermittedQuotes = [];
    localStorage.setItem('settings', JSON.stringify(newState));
  }

  getQuoteList() {
    return JSON.parse(localStorage.getItem('settings')).quoteList;
  }

  setQuoteList(quoteList: any) {
    const newState = JSON.parse(localStorage.getItem('settings'));
    const emptyGroupIndex = newState.quoteList.findIndex(item => item.group === '');
    if (emptyGroupIndex === (newState.quoteList.length - 1)) {
      newState.quoteList.splice(emptyGroupIndex, 0, quoteList);
    } else {
      newState.quoteList.push(quoteList);
    }
    localStorage.setItem('settings', JSON.stringify(newState));
  }

  addSymbol(symbol, group) {
    const newState = JSON.parse(localStorage.getItem('settings'));
    const groupIndex = newState.quoteList.findIndex(item => item.group === group);
    newState.quoteList[groupIndex].symbols.push(symbol);
    localStorage.setItem('settings', JSON.stringify(newState));
  }

  getTheme() {
    return JSON.parse(localStorage.getItem('settings')).darkTheme;
  }

  setTheme(darkTheme: Boolean) {
    const newState = { ...JSON.parse(localStorage.getItem('settings')), darkTheme };
    localStorage.setItem('settings', JSON.stringify(newState));
  }

  setWatchChart(newChart: any) {
    const newState = JSON.parse(localStorage.getItem('settings'));
    if (!newState.watchCharts.find(q => q.requestId === newChart.requestId) && newChart.status === 200) {
      newState.watchCharts.push(newChart);
      localStorage.setItem('settings', JSON.stringify(newState));
    }
  }

  getWatchCharts() {
    return JSON.parse(localStorage.getItem('settings')).watchCharts;
  }

  clearWatchCharts() {
    const newState = JSON.parse(localStorage.getItem('settings'));
    newState.watchCharts = [];
    localStorage.setItem('settings', JSON.stringify(newState));
  }

  removeWatchQuote(symbol: any) {
    const newState = JSON.parse(localStorage.getItem('settings'));
    newState.watchQuotes = newState.watchQuotes.filter(item => item.requestId !== symbol.requestId);
    localStorage.setItem('settings', JSON.stringify(newState));
  }

  updateQuoteList(symbolList) {
    const newState = JSON.parse(localStorage.getItem('settings'));
    newState.quoteList = symbolList;
    localStorage.setItem('settings', JSON.stringify(newState));
  }
}
