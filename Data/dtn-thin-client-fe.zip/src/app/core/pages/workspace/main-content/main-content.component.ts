import { Component, OnInit, ChangeDetectorRef, AfterViewChecked, OnDestroy } from '@angular/core';
import { DomStateService } from '@px-core/services/dom-state.service';

@Component({
  selector: 'app-main-content',
  templateUrl: './main-content.component.html',
  styleUrls: ['./main-content.component.scss']
})

export class MainContentComponent implements OnInit, AfterViewChecked, OnDestroy {

  isQuoteListExpanded = false;
  symbol = '';
  name = 'Workspace';
  isQuoteSymbolDetailsShown = false;

  options = [
    'My Workspace 1',
    'My Workspace 2',
    'My Workspace 3'
  ];

  selected = this.options[0];

  constructor(private cd: ChangeDetectorRef, private domStateService: DomStateService) {
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.domStateService.setQuoteSymbolExpanded(false);
  }

  ngAfterViewChecked() {
    if (this.isQuoteSymbolDetailsShown !== this.domStateService.isQuoteSymbolExpanded) {
      this.isQuoteSymbolDetailsShown = this.domStateService.isQuoteSymbolExpanded;
    }

    this.cd.detectChanges();
  }

  handleWorkspaceChange(selectedWorkspace: string) {
    this.selected = selectedWorkspace;
  }

  handleQuoteListExpand(isQuoteListExpanded: boolean) {
    this.isQuoteListExpanded = isQuoteListExpanded;
  }

  handleQuoteDetails(symbol: string) {
    this.symbol = symbol;
  }
}
