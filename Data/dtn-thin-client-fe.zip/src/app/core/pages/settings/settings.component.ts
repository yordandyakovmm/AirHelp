import { Component, OnInit } from '@angular/core';
import { ThrottleRequestService } from '@px-core/services/throttle-request.service';
import { StorageService } from '@px-core/services/storage.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
})
export class SettingsComponent implements OnInit {

  selectedInterval: Number;
  name: String = 'SETTINGS';

  refreshIntervals: { label: string, value: number }[] = [
    { label: '1 second', value: 1 },
    { label: '5 seconds', value: 5 },
    { label: '30 seconds', value: 30 },
    { label: '60 seconds', value: 60 },
    { label: '5 minutes', value: 300 },
    { label: 'Off (Manual Refresh)', value: 0 },
  ];

  dtnSupportMail = 'prophetx@dtn.com';
  dtnSupportSubject = 'DTN ProphetX Support';

  constructor(private throttleRequestService: ThrottleRequestService, private storageService: StorageService) {
    this.selectedInterval = this.storageService.getRefreshInterval();
  }

  ngOnInit() {
  }

  /**
   * Change or disable refresh interval of all watchers in the web app
   * @param {number} selectedInterval
   */
  changeRefreshInterval() {
    if (this.selectedInterval === 0) {
      // DISABLE ALL WATCHERS
      this.throttleRequestService.unwatch(true);
    } else {
      // CHANGE WATCH REFRESH INTERVAL
      this.throttleRequestService.changeRefreshInterval(this.selectedInterval);
    }
  }

}
