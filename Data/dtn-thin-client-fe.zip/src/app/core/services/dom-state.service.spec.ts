import { TestBed, inject } from '@angular/core/testing';

import { DomStateService } from './dom-state.service';

describe('DomStateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DomStateService]
    });
  });

  it('should be created', inject([DomStateService], (service: DomStateService) => {
    expect(service).toBeTruthy();
  }));
});
