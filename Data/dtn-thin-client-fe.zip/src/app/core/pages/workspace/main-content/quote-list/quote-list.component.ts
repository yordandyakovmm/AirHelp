import {
  Component,
  OnInit,
  OnDestroy,
  Output,
  Input,
  EventEmitter,
  AfterViewChecked,
  ChangeDetectorRef
} from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { AddSymbolDialogModel } from '@px-core/models/dialogs.model';
import { AddSymbolDialog } from '@px-shared/add-symbol-dialog/add-symbol.dialog';
import { ConfirmDialog } from '@px-shared/confirm-dialog/confirm.dialog';
import { ConfirmDialogModel } from '@px-core/models/dialogs.model';
import { QuoteService } from '@px-core/services/quote.service';
import { StorageService } from '@px-core/services/storage.service';
import { QuoteWatchRequest } from '@px-core/models/messages.model';
import { QuoteListModel, SymbolModel } from '@px-core/models/data.model';
import { ThrottleRequestService } from '@px-core/services/throttle-request.service';
import { Subscription } from 'rxjs/Subscription';
import { SortablejsOptions } from 'angular-sortablejs';
import { AsyncLocalStorage } from 'angular-async-local-storage';
import { ChartsService } from '@px-core/services/charts.service';
import * as faker from 'faker';
import { DomStateService } from '@px-core/services/dom-state.service';
import * as _ from 'lodash';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-quote-list',
  templateUrl: './quote-list.component.html',
  styleUrls: ['./quote-list.component.scss']
})
export class QuoteListComponent implements OnInit, OnDestroy, AfterViewChecked {

  isDisabled = false;
  quoteList = [];
  isSettingsBtnClicked = false;
  isQuoteListExpanded = false;
  expandedItemSymbolId = '';
  groupInfo = {};
  fields = [];
  parsedFields = [];
  expandedFields = [];
  valueChanges: any;
  isFullChartClose: boolean;
  editMode: Boolean = false;
  private subscription: Subscription;
  quoteListBackup = null;
  tempRemovedQuotes = [];
  sortableGroupOptions: SortablejsOptions = {
    disabled: true,
    scroll: true,
    scrollSensitivity: 50,
    forceFallback: false
  };

  sortableSymbolOptions: SortablejsOptions = {
    group: 'symbols',
    disabled: true,
    scroll: true,
    scrollSensitivity: 50,
    forceFallback: false
  };

  isQuoteListLoaded = false;
  quoteListData = [];

  @Output() quoteListExpand: EventEmitter<any> = new EventEmitter<boolean>();
  @Output() quoteDetails: EventEmitter<any> = new EventEmitter<string>();

  constructor(private quoteService: QuoteService,
    private storageService: StorageService,
    private dialog: MatDialog,
    private throttleRequestService: ThrottleRequestService,
    private localStorage: AsyncLocalStorage,
    private domStateService: DomStateService,
    private cd: ChangeDetectorRef,
    private chartsService: ChartsService) {

    this.subscription = this.quoteService.getQuoteMessage().subscribe(message => {
      if (message.data && !this.checkTempRemoved(message.meta.requestId)) {
        const foundGroupIndex = this.quoteList.findIndex(element => element.group === this.groupInfo[message.meta.requestId]);
        const group = this.quoteList[foundGroupIndex];

        if (group) {
          const foundSymbolIndex = group.symbols.findIndex(element => element.requestId === message.meta.requestId);
          const symbol = group.symbols[foundSymbolIndex];

          if (symbol) {
            if (Object.keys(symbol.data).length !== 0) {

              if (this.storageService.quoteListSymbols[symbol.expression] === undefined) {
                this.storageService.quoteListSymbols[symbol.expression] = new Subject();
              }

              const data = this.updateSymbolData(symbol.requestId, symbol.data, message, symbol.expression);

              Object.keys(data).forEach(key => {
                symbol.data[key] = data[key] === null ? '-' : data[key];
              });
            } else {
              const messageData = message.data[0];
              Object.keys(messageData).forEach(key => {
                symbol.data[key] = messageData[key] === null ? '-' : messageData[key];
              });
            }
          }
        }
      }

      if (message.errors) {
        const symbolName = message.errors[1] ? message.errors[1].detail : '';
        const errorMessage = message.errors[1] ? message.errors[1].code : '';

        const foundGroupIndex = this.quoteList.findIndex(element => element.group === this.groupInfo[symbolName]);
        const group = this.quoteList[foundGroupIndex];

        if (group) {
          const foundSymbolIndex = group.symbols.findIndex(element => element.expression === symbolName);
          const symbol = group.symbols[foundSymbolIndex];

          symbol.error.symbol = symbolName;
          symbol.error.message = errorMessage;
        }
      }

    });
  }

  ngOnInit() {
    this.quoteListData = this.storageService.getQuoteList();
    this.quoteListData.forEach(quoteGroup => {
      const singleQuoteGroup = {
        group: '',
        symbols: []
      };

      singleQuoteGroup.group = quoteGroup.group;

      quoteGroup.symbols.forEach((item) => {
        const refreshInterval = this.storageService.getRefreshInterval();
        const checkNotPermitted = this.storageService.getNotPermittedQuotes().filter(i => i.requestId === item.requestId);

        let symbolData;
        if (refreshInterval === 0 || checkNotPermitted) {
          const requestId = faker.random.uuid();
          symbolData = { ...item, requestId };
        } else {
          symbolData = item;
        }
        this.quoteService.symbolRequest(symbolData, refreshInterval);

        const symbol = {
          requestId: symbolData.requestId,
          expression: symbolData.expression,
          fields: symbolData.fields,
          data: {},
          error: {
            symbol: '',
            message: ''
          }
        };

        singleQuoteGroup.symbols.push(symbol);

        this.groupInfo[symbolData.expression] = quoteGroup.group;
        this.groupInfo[symbolData.requestId] = quoteGroup.group;
      });

      this.quoteList.push(singleQuoteGroup);
    });

    // getting fields
    this.fields = this.storageService.fields;
    this.parsedFields = this.fields.map(field => field.match(/([A-Z]?[^A-Z]*)/g).slice(0, -1).join(' '));
    this.expandedFields = this.parsedFields.slice(3, this.parsedFields.length);
  }

  ngOnDestroy(): void {
    this.isQuoteListLoaded = false;
    this.subscription.unsubscribe();
    this.throttleRequestService.unwatch(false);
  }

  ngAfterViewChecked() {

    if (this.isFullChartClose !== this.domStateService.isQuoteSymbolExpanded) {
      this.isFullChartClose = this.domStateService.isQuoteSymbolExpanded;
      this.cd.detectChanges();
    }
  }

  updateSymbolData(id: string, data: any, message: any, symbolName: string) {

    if (id === message.meta.requestId) {
      const messageData = message.data[0];

      Object.keys(messageData).forEach(key => {
        data[key] = messageData[key] === null ? '-' : messageData[key];
      });
    }

    if (this.storageService.quoteListSymbols[symbolName]) {
      this.storageService.quoteListSymbols[symbolName].next(data);
    }

    return data;
  }

  findById(id: string, collection: any) {
    let foundItem;

    collection.forEach((item) => {
      if (item.requestId === id) {
        foundItem = item;
      }
    });

    return foundItem;
  }

  showDetails(id: any) {
    let symbol;

    this.quoteList.forEach(quoteGroup => {
      const foundSymbol = this.findById(id, quoteGroup.symbols);

      if (foundSymbol) {
        symbol = foundSymbol;
      }
    });

    if (this.expandedItemSymbolId === id) {
      this.expandedItemSymbolId = '';
      this.quoteDetails.emit('');
      this.domStateService.setQuoteSymbolExpanded(false);
    } else {
      this.expandedItemSymbolId = id;
      this.quoteDetails.emit(symbol.expression);
      this.domStateService.setQuoteSymbolExpanded(true);
    }
  }

  hideDetails(id) {
    if (id === this.expandedItemSymbolId) {
      this.expandedItemSymbolId = '';
      this.quoteDetails.emit('');
      this.domStateService.setQuoteSymbolExpanded(false);
    }
  }

  checkIfDetailsExpand(id: any) {
    return this.expandedItemSymbolId === id;
  }

  showSettings() {
    this.domStateService.setQuoteSymbolExpanded(false);
    this.isSettingsBtnClicked = !this.isSettingsBtnClicked;
  }

  expandQuoteList() {
    this.isQuoteListExpanded = !this.isQuoteListExpanded;
    this.isDisabled = !this.isDisabled;
    this.isSettingsBtnClicked = false;
    this.quoteListExpand.emit(this.isQuoteListExpanded);
  }

  onAddSymbol() {
    const dialogRef = this.dialog.open(AddSymbolDialog, {
      panelClass: 'custom-dialog',
      width: '340px',
      position: { top: '193px' },
      data: new AddSymbolDialogModel(
        'Add Symbol',
        { cancel: 'Cancel', ok: 'Add Symbol' })
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        result.data.forEach(element => {
          const requestId = faker.random.uuid();
          this.groupInfo[requestId] = element.group;
          // tslint:disable-next-line:max-line-length
          const refreshInterval = this.storageService.getRefreshInterval();
          const symbol = new SymbolModel(element.symbol.symbol.symbol, this.storageService.fields, requestId);

          const groupIndex = this.quoteList.findIndex(q => q.group === element.group);
          this.quoteList[groupIndex].symbols.push({
            requestId,
            expression: element.symbol.symbol.symbol,
            fields: this.storageService.fields,
            data: {},
            error: {
              symbol: '',
              message: ''
            }
          });

          this.quoteList = [...this.quoteList];
          this.quoteService.symbolRequest(symbol, refreshInterval);
          this.storageService.addSymbol(symbol, element.group);
        });
      }
    });
  }

  onAddGroup() {
    const dialogRef = this.dialog.open(ConfirmDialog, {
      panelClass: 'custom-dialog',
      width: '340px',
      position: { top: '193px' },
      data: new ConfirmDialogModel('ADD GROUP', '', { cancel: 'Cancel', ok: 'Add Group' }, 'inputConfirm')
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const newGroup = new QuoteListModel(result.data, []);
        this.storageService.setQuoteList(newGroup);
        const emptyGroupIndex = this.quoteList.findIndex(item => item.group === '');
        if (emptyGroupIndex === (this.quoteList.length - 1)) {
          this.quoteList.splice(emptyGroupIndex, 0, newGroup);
        } else {
          this.quoteList.push(newGroup);
        }
        this.quoteList = [...this.quoteList];
      }
    });
  }

  onEditSelected() {
    this.quoteListBackup = _.cloneDeep(this.quoteList);
    this.editMode = true;
    this.sortableGroupOptions = { ...this.sortableGroupOptions, disabled: false };
    this.sortableSymbolOptions = { ...this.sortableSymbolOptions, disabled: false };
    this.isDisabled = true;
  }

  checkTempRemoved(requestId) {
    let result = false;
    if (this.tempRemovedQuotes.length) {
      this.tempRemovedQuotes.forEach(symbol => {
        if (symbol.requestId === requestId) {
          result = true;
        }
      });
    }
    return result;
  }

  removeSymbol(event, symbol, group) {
    const message = `This symbol is used for a chart, are you sure you want to delete the symbol and the chart?`;
    const symbolsOnChart = this.chartsService.getSymbolsOnChart();
    if (symbolsOnChart.find(expression => expression === symbol.expression)) {
      const dialogRef = this.dialog.open(ConfirmDialog, {
        panelClass: 'custom-dialog',
        width: '340px',
        position: { top: '193px' },
        data: new ConfirmDialogModel('WARNING', message, { cancel: 'Cancel', ok: 'Remove Symbol' })
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.symbolRemoveConfirmed(symbol, group);
        }
      });
    } else {
      this.symbolRemoveConfirmed(symbol, group);
    }
    event.stopPropagation();
  }

  symbolRemoveConfirmed(symbol, group) {
    const groupIndex = this.quoteList.findIndex(item => item.group === group);
    this.quoteList[groupIndex].symbols = this.quoteList[groupIndex].symbols.filter(element => element.requestId !== symbol.requestId);
    this.quoteList = [...this.quoteList];
    this.tempRemovedQuotes.push({ requestId: symbol.requestId, group, expression: symbol.expression });
    this.expandedItemSymbolId = '';
    this.quoteDetails.emit('');
  }

  removeGroup(event, group) {
    const symbolsOnChart = this.chartsService.getSymbolsOnChart();
    const groupIndex = this.quoteList.findIndex(item => item.group === group);
    let message = `Are you sure you want to delete ${group} group and all its symbols?`;
    this.quoteList[groupIndex].symbols.some(element => {
      if (symbolsOnChart.find(expression => expression === element.expression)) {
        return message += ' Some of the symbols are used for charts.';
      }
    });
    const dialogRef = this.dialog.open(ConfirmDialog, {
      panelClass: 'custom-dialog',
      width: '340px',
      position: { top: '193px' },
      data: new ConfirmDialogModel('WARNING', message, { cancel: 'Cancel', ok: 'Remove Group' })
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const newList = this.quoteList.filter(item => {
          if (item.group !== group) {
            return item;
          } else {
            if (item.symbols.length) {
              item.symbols.forEach(element => {
                this.tempRemovedQuotes.push({
                  requestId: element.requestId,
                  group,
                  expression: element.expression,
                  removeGroup: true
                });
              });
            } else {
              this.tempRemovedQuotes.push({
                requestId: null,
                group,
                expression: null,
                removeGroup: true
              });
            }
          }
        });
        this.quoteList = [...newList];
      }
    });
    event.stopPropagation();
  }

  onCancelQuoteChanges() {
    if (this.quoteListBackup) {
      this.quoteList = [...this.quoteListBackup];
    }
    this.quoteListBackup = null;
    this.editMode = false;
    this.tempRemovedQuotes = [];
    this.isSettingsBtnClicked = false;
    this.sortableGroupOptions = { ...this.sortableGroupOptions, disabled: true };
    this.sortableSymbolOptions = { ...this.sortableSymbolOptions, disabled: true };
    this.isDisabled = false;
  }

  onSaveQuoteChanges() {
    this.tempRemovedQuotes.forEach(element => {
      if (!element.removeGroup) {
        this.throttleRequestService.unwatchRequest(element.requestId);
        this.storageService.removeWatchQuote(element);
        this.chartsService.removeSymbolFromChart(element.expression);
      } else if (element.removeGroup && element.requestId) {
        this.throttleRequestService.unwatchRequest(element.requestId);
        this.storageService.removeWatchQuote(element);
        this.chartsService.removeSymbolFromChart(element.expression);
        if (element.group === '') {
          this.quoteList.push({ group: '', symbols: [] });
        }
      } else {
        if (element.group === '') {
          this.quoteList.push({ group: '', symbols: [] });
        }
      }
    });
    const newQuoteListState = this.quoteList.map(element => {
      return {
        group: element.group,
        symbols: element.symbols.map(symbol => {
          return _.pick(symbol, ['expression', 'fields', 'requestId']);
        })
      };
    });
    this.storageService.updateQuoteList(newQuoteListState);
    this.quoteListBackup = null;
    this.editMode = false;
    this.tempRemovedQuotes = [];
    this.isSettingsBtnClicked = false;
    this.sortableGroupOptions = { ...this.sortableGroupOptions, disabled: true };
    this.sortableSymbolOptions = { ...this.sortableSymbolOptions, disabled: true };
    this.isDisabled = false;
  }
}
