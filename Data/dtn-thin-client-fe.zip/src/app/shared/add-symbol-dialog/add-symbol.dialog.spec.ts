import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSymbolDialog } from './add-symbol.dialog';

describe('AddSymbolDialogComponent', () => {
  let component: AddSymbolDialog;
  let fixture: ComponentFixture<AddSymbolDialog>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddSymbolDialog ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddSymbolDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
