import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-workspaces-dropdown',
  templateUrl: './workspaces-dropdown.component.html',
  styleUrls: ['./workspaces-dropdown.component.scss']
})

export class WorkspacesDropdownComponent implements OnInit {

  @Input() options: any;
  @Output() onWorkspaceChange: EventEmitter<any> = new EventEmitter<string>();
  selectedWorkspace: string = "My workspace 1";
  show: boolean = false;

  constructor() { }

  ngOnInit() {
  }

  showDropdown() {
    this.show = !this.show;
  }

  select(selected: string) {
    this.selectedWorkspace = selected;
    this.onWorkspaceChange.emit(this.selectedWorkspace);
    this.show = !this.show;
  }
}
