import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@px-shared/shared.module';
import { MaterialModule } from '../material.module';
import { FormBuilder } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SettingsComponent } from './pages/settings/settings.component';
import { LoginComponent } from './pages/auth/login/login.component';
import { MatListModule, MatRadioModule } from '@angular/material';

import { WorkspaceComponent } from '@px-core/pages/workspace/workspace.component';

import { MainContentComponent } from '@px-core/pages/workspace/main-content/main-content.component';
import { NewsComponent } from '@px-core/pages/news/news.component';
import { QuoteListComponent } from '@px-core/pages/workspace/main-content/quote-list/quote-list.component';
// tslint:disable-next-line:max-line-length
import { QuoteGroupDetailsComponent } from '@px-core/pages/workspace/main-content/quote-list/quote-group-details/quote-group-details.component';
import { SymbolDetailsComponent } from '@px-core/pages/workspace/main-content/quote-list/symbol-details/symbol-details.component';
import { NewsTabComponent } from '@px-core/pages/workspace/main-content/news-tab/news-tab.component';
import { LayoutWorkspaceComponent } from './layouts/layout-workspace/layout-workspace.component';
import { LayoutAuthComponent } from './layouts/layout-auth/layout-auth.component';

import { WebsocketService } from '@px-core/services/websocket.service';
import { AuthUserService } from '@px-core/services/auth-user.service';
import { RouterModule } from '@angular/router';
import { MiniChartListComponent } from './pages/workspace/mini-charts/mini-chart-list/mini-chart-list.component';
import { MiniChartItemComponent } from './pages/workspace/mini-charts/mini-chart-item/mini-chart-item.component';
import { MiddleChartsComponent } from './pages/workspace/main-content/middle-charts/middle-charts.component';
import { ChartsService } from '@px-core/services/charts.service';
import { QuoteService } from '@px-core/services/quote.service';
import { ThrottleRequestService } from '@px-core/services/throttle-request.service';
import { StorageService } from '@px-core/services/storage.service';
import { SymbolSearchService } from '@px-core/services/symbol-search.service';
import { HttpClientModule } from '@angular/common/http';
import { WorkspacesDropdownComponent } from '@px-core/pages/workspace/main-content/workspaces-dropdown/workspaces-dropdown.component';
import { MiddleChartItemComponent } from './pages/workspace/main-content/middle-charts/middle-chart-item/middle-chart-item.component';
import { SortablejsModule } from 'angular-sortablejs';
import { AsyncLocalStorageModule } from 'angular-async-local-storage';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faExpand, faCompress, faClock } from '@fortawesome/free-solid-svg-icons';
import { DomStateService } from '@px-core/services/dom-state.service';
import { LoadingSettingsService } from '@px-core/services/loading-settings.service';

library.add(faExpand, faCompress, faClock);

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    MaterialModule,
    MatListModule,
    MatRadioModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule,
    SortablejsModule,
    FontAwesomeModule,
    AsyncLocalStorageModule,
  ],
  providers: [
    FormBuilder,
    WebsocketService,
    AuthUserService,
    ChartsService,
    QuoteService,
    ThrottleRequestService,
    StorageService,
    SymbolSearchService,
    DomStateService,
    LoadingSettingsService
  ],
  declarations: [
    SettingsComponent,
    LoginComponent,
    WorkspaceComponent,
    MainContentComponent,
    NewsComponent,
    QuoteListComponent,
    NewsTabComponent,
    LayoutWorkspaceComponent,
    LayoutAuthComponent,
    MiniChartListComponent,
    MiniChartItemComponent,
    QuoteGroupDetailsComponent,
    SymbolDetailsComponent,
    MiddleChartsComponent,
    MiddleChartItemComponent,
    WorkspacesDropdownComponent,
  ],
  exports: []
})

export class CoreModule { }
