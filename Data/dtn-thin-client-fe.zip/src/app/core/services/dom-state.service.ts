import { Injectable } from '@angular/core';

@Injectable()
export class DomStateService {

  isQuoteSymbolExpanded = false;

  constructor() { }

  setQuoteSymbolExpanded(expanded: boolean) {
    return this.isQuoteSymbolExpanded = expanded;
  }
}
