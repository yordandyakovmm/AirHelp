import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WebsocketService } from '@px-core/services/websocket.service';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { QuoteWatchRequest, QuoteSnapRequest } from '@px-core/models/messages.model';
import { StorageService } from '@px-core/services/storage.service';

@Injectable()
export class QuoteService {

  private chartSnap = new Subject<any>();
  private chartWatch = new Subject<any>();
  private quoteMessage = new Subject<any>();

  constructor(private webSocketService: WebsocketService, private storageService: StorageService) {
    this.webSocketService.getWebSocketMessage().subscribe(({ data }) => {
      if (data.meta.command.toLowerCase() === 'quotewatch' ||
        data.meta.command.toLowerCase() === 'quotesnap') {
        if (data.meta.command.toLowerCase() === 'quotesnap') {
          this.onNext(data);
        } else {
          this.storageService.setWatchQuote(data.meta);
          this.onNext(data);
        }
      }
    });
  }

  onNext(message: any) {
    if (message.meta.command.toLowerCase() === 'quotewatch') {
      this.chartSnap.next(message.data);
      this.quoteMessage.next(message);
    }
    if (message.meta.command.toLowerCase() === 'quotesnap') {
      this.chartWatch.next(message);
      this.quoteMessage.next(message);
    }
  }

  symbolRequest(symbol: any, updateInterval: number) {
    let  data;
    if (updateInterval !== 0) {
      data = new QuoteWatchRequest(symbol.requestId, symbol.expression, symbol.fields, updateInterval);
    } else {
      data = new QuoteSnapRequest(symbol.requestId, symbol.expression, symbol.fields);
    }
    this.webSocketService.send(data);
  }

  getQuoteMessage(): Observable<any> {
    return this.quoteMessage.asObservable();
  }
}
