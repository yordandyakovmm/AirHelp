import { AfterViewInit, Component, ElementRef, OnInit, OnDestroy } from '@angular/core';
import { Chart } from 'chart.js';
import { ChartsService } from '@px-core/services/charts.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-mini-chart-list',
  templateUrl: './mini-chart-list.component.html',
  styleUrls: ['./mini-chart-list.component.scss']
})
export class MiniChartListComponent implements OnInit, AfterViewInit, OnDestroy {

  miniCharts = ['@C@1', '@W@1', '@S@1', '@MW@1'];
  chart = [];
  private symbolsAdd: Subscription;
  private symbolsRemoved: Subscription;

  constructor( private elementRef: ElementRef, private chartsService: ChartsService) {
  }

  ngOnInit() {
    this.symbolsAdd = this.chartsService.listenForSymbolAdded().subscribe(symbol => {
      if (symbol.type = 'mini-chart') {
        this.miniCharts.push(symbol.expression);
      }
    });
    this.symbolsRemoved = this.chartsService.listenForSymbolRemoved().subscribe(symbol => {
      this.miniCharts = this.miniCharts.filter(s => s !== symbol.expression);
    });
  }

  ngAfterViewInit() {
  }

  ngOnDestroy(): void {
    this.symbolsRemoved.unsubscribe();
    this.symbolsAdd.unsubscribe();
  }
}
