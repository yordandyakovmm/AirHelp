import { TestBed, inject } from '@angular/core/testing';

import { ThrottleRequestService } from './throttle-request.service';

describe('ThrottleRequestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ThrottleRequestService]
    });
  });

  it('should be created', inject([ThrottleRequestService], (service: ThrottleRequestService) => {
    expect(service).toBeTruthy();
  }));
});
