import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LayoutWorkspaceComponent } from './layout-workspace.component';

describe('LayoutWorkspaceComponent', () => {
  let component: LayoutWorkspaceComponent;
  let fixture: ComponentFixture<LayoutWorkspaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LayoutWorkspaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LayoutWorkspaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
