import { NgModule } from '@angular/core';

import {
  MatButtonModule,
  MatCheckboxModule,
  MatInputModule,
  MatCardModule,
  MatGridListModule,
  MatSidenavModule,
  MatToolbarModule,
  MatIconModule,
  MatSelectModule,
  MatFormFieldModule,
  MatDialogModule,
  MatTooltipModule,
  MatExpansionModule
} from '@angular/material';

@NgModule({
    imports: [
      MatButtonModule,
      MatCheckboxModule,
      MatInputModule,
      MatCardModule,
      MatGridListModule,
      MatSidenavModule,
      MatToolbarModule,
      MatIconModule,
      MatSelectModule,
      MatFormFieldModule,
      MatDialogModule,
      MatTooltipModule,
      MatExpansionModule
    ],
    exports: [
      MatButtonModule,
      MatCheckboxModule,
      MatInputModule,
      MatCardModule,
      MatGridListModule,
      MatSidenavModule,
      MatToolbarModule,
      MatIconModule,
      MatSelectModule,
      MatFormFieldModule,
      MatDialogModule,
      MatTooltipModule,
      MatExpansionModule
    ]
})
export class MaterialModule { }
