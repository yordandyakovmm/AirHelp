import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { WebsocketService } from '@px-core/services/websocket.service';
import { SymbolSearchRequest } from '@px-core/models/messages.model';
import { StorageService } from '@px-core/services/storage.service';

@Injectable()
export class SymbolSearchService {
    private onSymbolSearchData = new Subject<any>();

    constructor(private ws: WebsocketService) {
      this.ws.getWebSocketMessage().subscribe(({ data }) => {
        if (data.meta.command.toLowerCase() === 'symbolsearch') {
          this.onNext(data);
        }
      });
    }

    onNext(data: any) {
        this.onSymbolSearchData.next({ data });
    }

    searchForSymbol(symbol: String) {
      const message = new SymbolSearchRequest(symbol);
      this.ws.send(message);
    }

    getSearchResults(): Observable<any> {
      return this.onSymbolSearchData.asObservable();
    }
}
