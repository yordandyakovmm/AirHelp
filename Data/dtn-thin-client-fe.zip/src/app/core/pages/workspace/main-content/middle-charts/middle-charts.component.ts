import { Component, OnInit, OnDestroy } from '@angular/core';
import { ChartsService } from '@px-core/services/charts.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-middle-charts',
  templateUrl: './middle-charts.component.html',
  styleUrls: ['./middle-charts.component.scss']
})
export class MiddleChartsComponent implements OnInit, OnDestroy {

  symbols: string[] = ['@S@1'];
  newSymbolName: string = '';
  private symbolsAdd: Subscription;
  private symbolsRemoved: Subscription;

  constructor(private chartsService: ChartsService) {
  }

  ngOnInit() {
    this.symbolsAdd = this.chartsService.listenForSymbolAdded().subscribe(symbol => {
      if (symbol.type = 'middle-chart') {
        this.symbols.push(symbol.expression);
      }
    });
    this.symbolsRemoved = this.chartsService.listenForSymbolRemoved().subscribe(symbol => {
        this.symbols = this.symbols.filter(s => s !== symbol.expression);
    });
  }

  ngOnDestroy(): void {
    this.symbolsRemoved.unsubscribe();
    this.symbolsAdd.unsubscribe();
  }

  onSubmitAddSymbolForm() {
    this.chartsService.addSymbolOnChart(this.newSymbolName, 'middle-chart');
  }


}
