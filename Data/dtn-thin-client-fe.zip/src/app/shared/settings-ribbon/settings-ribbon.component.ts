import { Component, OnInit, Input } from '@angular/core';
import { AuthUserService } from '@px-core/services/auth-user.service';

@Component({
  selector: 'app-settings-ribbon',
  templateUrl: './settings-ribbon.component.html',
  styleUrls: ['./settings-ribbon.component.scss']
})
export class SettingsRibbonComponent implements OnInit {

  @Input() name: string;
  loggedUser: String = null;

  constructor(private authUserService: AuthUserService) {
    this.loggedUser = this.authUserService.loggedUser;
  }

  ngOnInit() {
  }

}
