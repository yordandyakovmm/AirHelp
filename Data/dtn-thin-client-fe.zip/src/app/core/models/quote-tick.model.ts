export class QuoteTick {
  Ask: string;
  AskSize: number;
  Bid: string;
  BidSize: number;
  Change: string;
  High: string;
  IssueDescription: string;
  Last: string;
  Low: string;
  Open: string;
  OpenInterest: number;
  Volatility: number;
  Volume: number;
}
