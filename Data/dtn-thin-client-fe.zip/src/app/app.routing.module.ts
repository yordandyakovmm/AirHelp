import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from '@px-core/pages/auth/login/login.component';
import { SettingsComponent } from '@px-core/pages/settings/settings.component';
import { WorkspaceComponent } from '@px-core/pages/workspace/workspace.component';
import { NewsComponent } from '@px-core/pages/news/news.component';
import { PageNotFoundComponent } from '@px-shared/page-not-found//page-not-found.component';
import { AuthGuard } from '@px-core/guards/auth.guard';
import { LayoutWorkspaceComponent } from '@px-core/layouts/layout-workspace/layout-workspace.component';
import { LayoutAuthComponent } from '@px-core/layouts/layout-auth/layout-auth.component';

const routes: Routes = [
  // ROUTES USING WORKSPACE LAYOUT
  {
    path: '', component: LayoutWorkspaceComponent, children: [
      { path: '', redirectTo: '/workspaces', pathMatch: 'full' },
      { path: 'workspaces', component: WorkspaceComponent, canActivate: [AuthGuard] },
      { path: 'news', component: NewsComponent, canActivate: [AuthGuard] },
      { path: 'settings', component: SettingsComponent, canActivate: [AuthGuard] },
    ]
  },
  // ROUTES USING AUTH LAYOUT
  {
    path: '', component: LayoutAuthComponent, children: [
      { path: 'login', component: LoginComponent },
      { path: '**', component: PageNotFoundComponent }
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  providers: [AuthGuard],
  declarations: []
})

export class AppRoutingModule {
}
