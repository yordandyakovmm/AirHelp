import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { WebsocketService } from '@px-core/services/websocket.service';
import { LogInMessage } from '@px-core/models/messages.model';
import { Router } from '@angular/router';
import { StorageService } from '@px-core/services/storage.service';

@Injectable()
export class AuthUserService {
    private onAuthUser = new Subject<any>();
    isAuthenticated: Boolean = false;
    loggedUser: String = null;
    public forcedLogout = null;

    constructor(private ws: WebsocketService, private router: Router, private storageService: StorageService) {
      this.ws.getWebSocketMessage().subscribe(({ data }) => {
        if (data.meta.command.toLowerCase() === 'login') {
          if (data.errors && data.errors[0].code.toString().toLowerCase() === 'forced logout') {
            this.storageService.clearWatchQuotes();
            this.logOut();
            this.router.navigate(['/login']);
            this.forcedLogout = data;
          }
          if (this.forcedLogout && data.errors[0].code === 1006) {
            this.onNext(this.forcedLogout);
            this.forcedLogout = null;
          } else {
            this.onNext(data);
          }

        }
      });
    }

    onNext(data: any) {
        this.isAuthenticated = data.errors ? false : true;
        this.loggedUser = data.errors ? null : data.data[0].username;
        this.onAuthUser.next({ data });
    }

    getAuthUser(): Observable<any> {
        return this.onAuthUser.asObservable();
    }

    hasAuthUser(): Boolean {
      return this.isAuthenticated;
    }

    authenticate(username: string, password: string) {
      const message = new LogInMessage(username, password);
      this.ws.connect(message);
    }

    logOut() {
      this.isAuthenticated = false;
      this.ws.disconnect();
    }
}
