import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-quote-group-details',
  templateUrl: './quote-group-details.component.html',
  styleUrls: ['./quote-group-details.component.scss']
})
export class QuoteGroupDetailsComponent implements OnInit {

  @Input() data: any;
  @Input() fields: any;
  @Input() parsedFields: any;

  firstColumnData = [];
  secondColumnData = [];
  length: number;

  constructor() { }

  ngOnInit() {
    this.parsedFields = this.parsedFields.slice(3, this.parsedFields.length);
    this.fields = this.fields.slice(3, this.fields.length);
    this.length = Math.round(this.parsedFields.length / 2);

    for (let index = 0; index < this.length; index++) {
      this.firstColumnData.push(this.parsedFields[index]);
    }

    for (let index = this.length; index < this.parsedFields.length; index++) {
      this.secondColumnData.push(this.parsedFields[index]);
    }
  }

}
