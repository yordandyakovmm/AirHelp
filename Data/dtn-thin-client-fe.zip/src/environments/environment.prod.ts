export const environment = {
  production: true,
  version: '0.7.0',
  apiBaseUrl: 'https://ws1.dtn.com/',
  wsAppName: 'ThinClient',
  wsBaseUrl: 'wss://MarketDataAPI.dtn.com/cs/1.0'
};
