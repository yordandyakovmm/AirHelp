export class ConfirmDialogModel {
  title: string;
  message: string;
  mode: string;
  buttons: { cancel: string, ok: string };
  constructor(title: string,
              message: string,
              buttons: { cancel: string, ok: string },
              mode?: string) {
    this.title = title;
    this.message = message;
    this.buttons = buttons;
    this.mode = mode ? mode : 'confirm';
  }
}

export class AddSymbolDialogModel {
  title: string;
  buttons: { cancel: string, ok: string };
  constructor(title: string,
              buttons: { cancel: string, ok: string }) {
    this.title = title;
    this.buttons = buttons;
  }
}
