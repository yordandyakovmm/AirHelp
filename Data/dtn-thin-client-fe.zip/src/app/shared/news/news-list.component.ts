import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-news-list',
  templateUrl: './news-list.component.html',
  styleUrls: ['./news-list.component.scss']
})
export class NewsListComponent implements OnInit {
  // remove the value of the property once you connect the websocket data
  @Input() newsResponse: any;
  @Input() isTabNews: Boolean = false;

  constructor() { }

  ngOnInit() {
  }

}
