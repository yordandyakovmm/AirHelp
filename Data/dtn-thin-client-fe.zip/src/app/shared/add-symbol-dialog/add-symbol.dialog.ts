import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-add-symbol-dialog',
  styleUrls: ['./add-symbol.dialog.scss'],
  templateUrl: './add-symbol.dialog.html'
})
// tslint:disable-next-line:component-class-suffix
export class AddSymbolDialog {
  addSymbolsState = [];
  constructor(
    public dialogRef: MatDialogRef<AddSymbolDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onCancelClick(): void {
    this.dialogRef.close();
  }

  save(): void {
    this.dialogRef.close({ data: this.addSymbolsState });
  }

  onAddSymbolStateChange(state) {
    this.addSymbolsState = state;
  }
}
