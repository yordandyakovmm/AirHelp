import { TestBed, inject } from '@angular/core/testing';

import { LoadingSettingsService } from './loading-settings.service';

describe('LoadingSettingsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoadingSettingsService]
    });
  });

  it('should be created', inject([LoadingSettingsService], (service: LoadingSettingsService) => {
    expect(service).toBeTruthy();
  }));
});
