export const environment = {
  production: false,
  version: '0.7.0',
  apiBaseUrl: 'https://ws1.dtn.com/',
  wsAppName: 'ThinClient',
  wsBaseUrl: 'wss://ProphetX14.dtn.com/cs/1.0'
};
