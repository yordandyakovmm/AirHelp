import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news-tab',
  templateUrl: './news-tab.component.html',
  styleUrls: ['./news-tab.component.scss']
})
export class NewsTabComponent implements OnInit {
  // remove the value of the property once you connect the websocket data
  newsFormMessage: any = [
    { img: 'http://i.imgur.com/hfH9CiC.png', creator: 'The PRICE Futures Group', title: 'Morning Grains Report', date: '37 minutes ago' },
    { img: 'http://i.imgur.com/hfH9CiC.png', creator: 'The Hueber Report', title: 'Morning Grain Market Research', date: '49 minutes ago' },
    {
      // img: 'http://i.imgur.com/hfH9CiC.png',
      creator: 'RCG Direct',
      title: 'Daily Technical Spotlight - January Soybeans',
      date: 'Thu Nov 16, 9:16AM CST'
    }];
  constructor() { }

  ngOnInit() {
  }

}
