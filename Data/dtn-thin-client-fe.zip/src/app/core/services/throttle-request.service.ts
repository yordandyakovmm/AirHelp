import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { WebsocketService } from '@px-core/services/websocket.service';
import { ThrottleChangeRequest, UnwatchRequest } from '@px-core/models/messages.model';
import { StorageService } from '@px-core/services/storage.service';

@Injectable()
export class ThrottleRequestService {
  private onRefreshIntervalChange = new Subject<any>();

  constructor(private ws: WebsocketService, private storageService: StorageService) {
    this.ws.getWebSocketMessage().subscribe(({ data }) => {
      if (data.meta.command.toLowerCase() === 'throttlechange') {
        const refreshInterval = data.data[0].updateInterval;
        storageService.setRefreshInterval(refreshInterval);
        this.onNext(data);
      }
      if (data.meta.command.toLowerCase() === 'unwatch') {
        this.onNext(data);
      }
    });
  }

  onNext(data: any) {
    this.onRefreshIntervalChange.next({ data });
  }

  changeRefreshInterval(refreshInterval: Number) {
    const message = new ThrottleChangeRequest(refreshInterval);
    this.ws.send(message);
  }

  unwatch(changeRefreshInterval: boolean) {
    const watchQuotes = this.storageService.getWatchQuotes();
    const watchCharts = this.storageService.getWatchCharts();
    if (watchQuotes) {
      watchQuotes.forEach(element => {
        const message = new UnwatchRequest(element.requestId);
        this.ws.send(message);
      });
    }
    if (watchCharts) {
      watchCharts.forEach(element => {
        const message = new UnwatchRequest(element.requestId);
        this.ws.send(message);
      });
    }
    if (changeRefreshInterval) {
      this.storageService.setRefreshInterval(0);
    }
    this.storageService.clearWatchQuotes();
    this.storageService.clearWatchCharts();
  }

  unwatchRequest(requestId) {
    const message = new UnwatchRequest(requestId);
    this.ws.send(message);
  }
}
