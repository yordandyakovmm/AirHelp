import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteQroupDetailsComponent } from './quote-qroup-details.component';

describe('QuoteQroupDetailsComponent', () => {
  let component: QuoteQroupDetailsComponent;
  let fixture: ComponentFixture<QuoteQroupDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuoteQroupDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteQroupDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
