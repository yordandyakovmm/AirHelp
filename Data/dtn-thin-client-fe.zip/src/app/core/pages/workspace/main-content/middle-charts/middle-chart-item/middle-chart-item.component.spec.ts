import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiddleChartItemComponent } from './middle-chart-item.component';

describe('MiddleChartItemComponent', () => {
  let component: MiddleChartItemComponent;
  let fixture: ComponentFixture<MiddleChartItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiddleChartItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiddleChartItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
