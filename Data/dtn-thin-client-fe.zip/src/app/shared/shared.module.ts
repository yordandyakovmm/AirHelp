import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from '@px-shared/navbar/navbar.component';
import { FooterComponent } from '@px-shared/footer/footer.component';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../material.module';
import { AuthUserService } from '@px-core/services/auth-user.service';
import { NewsListComponent } from '@px-shared/news/news-list.component';
import { ConfirmDialog } from '@px-shared/confirm-dialog/confirm.dialog';
import { AddSymbolDialog } from '@px-shared/add-symbol-dialog/add-symbol.dialog';
import { PageNotFoundComponent } from '@px-shared/page-not-found/page-not-found.component';
import { SettingsRibbonComponent } from '@px-shared/settings-ribbon/settings-ribbon.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddSymbolComponent } from '@px-shared/add-symbol/add-symbol.component';
import { SpinnerComponent } from '@px-shared/spinner/spinner.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    CommonModule,
    NavbarComponent,
    FooterComponent,
    NewsListComponent,
    ConfirmDialog,
    AddSymbolDialog,
    SettingsRibbonComponent,
    SpinnerComponent,
  ],
  declarations: [
    NavbarComponent,
    FooterComponent,
    NewsListComponent,
    ConfirmDialog,
    AddSymbolDialog,
    PageNotFoundComponent,
    SettingsRibbonComponent,
    AddSymbolComponent,
    SpinnerComponent
  ],
  providers: [AuthUserService],
  entryComponents: [
    ConfirmDialog,
    AddSymbolDialog
  ]
})
export class SharedModule { }
